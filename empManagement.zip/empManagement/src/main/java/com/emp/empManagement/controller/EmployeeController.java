package com.emp.empManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.emp.empManagement.dto.EmployeeDto;
import com.emp.empManagement.model.Employee;
import com.emp.empManagement.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/employees")
	public ResponseEntity<String> addEmp(@RequestBody EmployeeDto request) {
		try {
			employeeService.addEmp(request);
			return ResponseEntity.ok("Employee Created");
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@GetMapping("/employees")
	public List<Employee> findAll() {
		try {
			return employeeService.findAll();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
			
	}
	
	@GetMapping("employees/{id}")
	public ResponseEntity<Employee> findById(@PathVariable long id) {
		try {
			Optional<Employee> res = employeeService.findById(id);
			if(res.isPresent()) {
				return ResponseEntity.ok(res.get());
			}
			else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@PutMapping("employees/{id}")
	public ResponseEntity<String> updateEmp(@PathVariable long id, @RequestBody EmployeeDto request) {
		try {
			int rowsAffected = employeeService.updateEmp(id, request);
			
			if(rowsAffected > 0) {
				employeeService.updateEmp(id, request);
				return ResponseEntity.ok("Employee updated");
			}
			else {
				return ResponseEntity.badRequest().body("Employee with id " + id + " not found");
			}
					}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable long id) {
		try {
			employeeService.deletEmp(id);
			return ResponseEntity.ok("Employee data deleted");
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
	

}
