package com.emp.empManagement.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.emp.empManagement.dto.EmployeeDto;
import com.emp.empManagement.model.Employee;
import com.emp.empManagement.model.rowmapper.EmployeeRowMapper;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Employee> findAll() {
		String sql = "SELECT * FROM employee";
		return jdbcTemplate.query(sql, new EmployeeRowMapper());
	}

	@Override
	public void addEmp(EmployeeDto employeeDto) {
		String sql = "INSERT INTO employee (first_name, last_name, email, created_at, updated_at) VALUES (?, ?, ?, ?, ?)";
		jdbcTemplate.update(sql, employeeDto.getFirstName(), employeeDto.getLastName(), employeeDto.getEmail(), new Timestamp(System.currentTimeMillis()).toLocalDateTime(), new Timestamp(System.currentTimeMillis()).toLocalDateTime());
	}

	@Override
	public int updateEmp(long id, EmployeeDto request) {
		String sql = "UPDATE employee SET first_name = ?, last_name = ?, email = ?, updated_at = ? WHERE id = ?";
		return jdbcTemplate.update(sql, request.getFirstName(), request.getLastName(), request.getEmail(), new Timestamp(System.currentTimeMillis()).toLocalDateTime(), id);
	}

	@Override
	public Optional<Employee> findById(long id) {
		String sql = "SELECT * FROM employee where id = ?";
		return Optional.ofNullable(jdbcTemplate.queryForObject(sql, new EmployeeRowMapper(), id));
	}

	@Override
	public void deleteEmp(long id) {
		String sql = "DELETE FROM employee WHERE id = ?";
		jdbcTemplate.update(sql, id);
		
	}
}
