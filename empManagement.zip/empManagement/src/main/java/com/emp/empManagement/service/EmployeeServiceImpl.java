package com.emp.empManagement.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.empManagement.dto.EmployeeDto;
import com.emp.empManagement.model.Employee;
import com.emp.empManagement.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void addEmp(EmployeeDto request) {
		employeeRepository.addEmp(request);
	}

	@Override
	public List<Employee> findAll() {
		return employeeRepository.findAll();
	}

	@Override
	public Optional<Employee> findById(long id) {
		return employeeRepository.findById(id);
	}

	@Override
	public int updateEmp(long id, EmployeeDto request) {
		return employeeRepository.updateEmp(id, request);
	}

	@Override
	public void deletEmp(long id) {
		employeeRepository.deleteEmp(id);
	}

}
